package whatisanobject;

public class ClassA {
	
	public static void main(String[] args) {
		
		ClassB instanceOne = new ClassB();
		
		instanceOne.methodOne();
		
		ClassB instanceTwo = new ClassB();
		
		instanceTwo.methodTwo();
		
	}

}















