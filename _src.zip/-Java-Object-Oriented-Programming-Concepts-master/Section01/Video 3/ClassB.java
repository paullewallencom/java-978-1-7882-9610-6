package howobjectsinteract.one;

import howobjectsinteract.two.ClassD;

public class ClassB extends ClassC {

	public void method(){
		
		this.publicMethod();
		this.protectedMethod();
		this.privateMethod();
		this.defaultMethod();
		
	}
	
}