/* The package statement */ 
package whatisaclasse.one;

/* The import statements */
import java.util.ArrayList; 

/* The Class declaration */ 
public class ClassA {
	
	public static void main(String[] args) {
		ArrayList<String> myList = new ArrayList<String>();
		myList.add("hello world !!");	
	}
	
	// Code ... 
	public void myMethod(){}
}

//public class ClassC{}
class ClassD{}
class ClassE{}

