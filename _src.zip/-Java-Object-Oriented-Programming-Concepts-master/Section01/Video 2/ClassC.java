package whatisaclasse.two;

public class ClassC {
	
	// State
	public String myString = "something"; 
	
	// behaviour
	public void doSomething() {
		System.out.println(myString);
	}
	
}
