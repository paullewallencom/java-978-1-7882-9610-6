package whatisaclasse.two;

public class ClassD {

	public static void main(String[] args) {
		ClassC c = new ClassC();
		c.doSomething();
	
	}
	
}
