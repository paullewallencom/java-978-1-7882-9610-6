package inheritance.polymorphism;

public enum Cargo {
	PASSENGERS,
	CARGO,
	WATER
}
