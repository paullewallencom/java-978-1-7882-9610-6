package abstratc.interfaces;

public enum Cargo {
	PASSENGERS,
	CARGO,
	WATER
}
