package abstratc.interfaces;

public interface FireFighterPlane extends AeroPlane{

	void dropWater();
	
}
