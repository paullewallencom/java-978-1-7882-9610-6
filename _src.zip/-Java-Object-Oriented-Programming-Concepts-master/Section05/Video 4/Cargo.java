package mixins.traits;

public enum Cargo {
	PASSENGERS,
	CARGO,
	WATER
}
