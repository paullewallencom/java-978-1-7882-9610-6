package hashcode.equals;

public class Policy {

	public long id;

	public Policy(long id) {
		this.id = id;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
