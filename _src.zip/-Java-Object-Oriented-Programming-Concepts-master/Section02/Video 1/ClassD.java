package encapsulation;

public class ClassD {

	public static void someMethod(){
		ClassA instanceOne = new ClassA();
		//instanceOne.setVariable(55.12345678);
	}
}
