package encapsulation;

public class ClassE {

	public static void someMethod(){
		ClassA instanceOne = new ClassA();
		//instanceOne.setVariable(1000.12341234);
	}
}
