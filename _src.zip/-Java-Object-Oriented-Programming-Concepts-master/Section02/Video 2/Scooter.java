package abstraction;

public class Scooter extends Vehicle{

	public Scooter(double con, double aut, int cap, Cargo car) {
		super(con, aut, cap, car);
		// TODO Auto-generated constructor stub
	}
}
