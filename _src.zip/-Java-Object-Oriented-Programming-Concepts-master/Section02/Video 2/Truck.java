package abstraction;

public class Truck extends Vehicle{

	public Truck(double con, double aut, int cap, Cargo car) {
		super(con, aut, cap, car);
		// TODO Auto-generated constructor stub
	}
}