package abstraction;

public enum Cargo {
	PASSENGERS,
	MERCHANDISE
}
