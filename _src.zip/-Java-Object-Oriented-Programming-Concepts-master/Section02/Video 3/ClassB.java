package inheritance;

public abstract class ClassB extends ClassA{

	public abstract void somMethod2();
}
