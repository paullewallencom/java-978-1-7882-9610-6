package inheritance;

public enum BicycleType {
	MOUNTAIN_BIKE,
	HYBRID,
	STUNT
}
