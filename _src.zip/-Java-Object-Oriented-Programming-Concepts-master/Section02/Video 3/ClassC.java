package inheritance;

public class ClassC extends ClassB{

	@Override
	public void somMethod2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void someMethod1() {
		// TODO Auto-generated method stub
		
	}

}
