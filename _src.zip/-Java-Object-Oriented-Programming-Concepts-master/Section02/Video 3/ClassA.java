package inheritance;

public abstract class ClassA {

	public abstract void someMethod1();
}
